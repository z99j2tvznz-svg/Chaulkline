# Chalkline design notes (not built yet; build only when user says "make it")

## Table detection
- Auto: felt, corner pockets, side pockets. Retry with tips, or tap the 4 corner pockets (sides assumed).
- NEW: also detect the rail diamond dots as a second way to find the table (RANSAC lines through the dots, homography to top-down). Helps with glare or a hidden pocket. Source idea: pix2pockets paper.
- NEW: setup hint, frame the table so it fills about 40% or more of the screen (detection drops a lot when it is small).
- Reference bar: Railbird finds the table from any phone position as long as six pockets are visible.

## Play screen (sideways, full screen, no writing during play)
- Tip diagram, strength 1-10, option arrows, Safe/Bold slider, menu buttons only. Text lives in training mode.
- Pick a candidate, it locks and stays drawn even if someone blocks the camera. Re-read the table only when the cue ball has moved a meaningful distance and held still for a moment.
- Landing zone: green brightest at the ideal distance, fading nearer and farther. Amber and red only along the sides and only where the situation calls for them. Hatched shadow behind blocking balls. Zone stops at the cushions.
- This shot: simple tier = one real curved line (spin and speed included). Advanced tier = draw/stun/follow slices plus the target zone, player decides. Side spin later.
- Aim always at pocket center. Cheating the pocket only in the math, shown only on Bold.
- Second slider later: run-out depth (next shot only to full run-out), tied to skill and aggression.

## Pocket style
- Three choices only: Pro (tight), Amateur, Bar box. No custom. Difficulty dial for planner margins only, never the physics.

## Tables and profiles
- Per-table profiles (name + GPS suggestion). New table starts from clean textbook physics. Refelt: reset buried in settings, plus a gentle drift suggestion based on simple shots only, never automatic.

## Shots, banks, breaks, scratches
- Everything automatic from the camera. No made/missed prompts.
- Bank/kick: aim in diamonds, per-rail corrections learned from every real shot.
- Break: observational, live nudge only at the break (like "last 3 scratched, move here").
- Scratch or ball off table: wait for the cue ball to be placed, suggest ball-in-hand spot looking 3 balls ahead.
- Hand-reset of an attempt is recognized and not counted as a result. Bumped object balls do not matter until the next shot.
- New game inferred from a full rack appearing again.

## After the session
- One stats screen: make rate, breaks, bank/kick learning, decision quality (what you chose vs the top option), optional one-tap session rating.
- Shot list with trimmed clips (3 sec before the shot to 1-2 sec after balls stop) plus a top-down diagram of the shot. Top 10 shots, top 10 misses, filters. Star a clip to save it to the phone.

## Other
- Billiard theory baked into scoring: cluster break-up, safety vs pot, cue ball path into the shot line.
- TV mode (bigger, higher contrast) for AirPlay mirroring.
- Not doing: social feed, match score tracking, pro-footage learning, humidity drift, multi-camera (maybe v3), left/right spin (later).

## Look and feel (decided)
- Always dark, premium, simple, modern with a little style. Frosted-glass panels, thin type (Inter, light weights for big numbers), one accent only.
- Accent: ice teal (#59d6e8). Gold was the alternative, not chosen.
- Landing zone look approved (green core fading with distance, amber/red only on the sides where they apply). Number tags on balls (5, 7) shown in the mockup.
- Reference mockup: scratchpad/real/out5.png (drawn over the user's Diamond-table photo; geometry there is placeholder, not real physics).
- Mock layout: top glass pills (Menu, game, Plan, more), bottom-left glass panel (cue-tip diagram, big strength number, option arrows), Safe-to-Bold slider on the right edge.
- Ball number tags over the balls: a menu toggle, OFF by default. Use it to double-check the app identified the balls correctly.

## Keeping the math small (battery and heat)
- Do not calculate constantly. Plan only when the table has settled; analyze the camera less often while you line up a shot.
- Prune first with geometry and theory: for each object ball keep only the pockets it can really reach (cut angle possible, nothing blocking), then only cue-ball lanes that are clear. Run the full physics (speed, spin, position) only on the few survivors. Banks and combos get their own small pass, only when direct shots are weak or a safety is better.
- Theory layer: check the layout against several known patterns at once, weigh how strongly each applies, and blend their suggestions instead of picking one rule.
- User says lighting is not a concern for now (home and good-light venues).

## Resume session
- Save session state after every shot (shots, results, table profile, mode, aggression). Save clips to local storage as they are recorded.
- If the last session ended abnormally (battery, call, crash), the home screen shows a Resume card (shot count, time ago) with Resume and Discard.
- Limits: clip for the shot in progress may be lost; the camera may re-ask permission after a restart on the Home Screen app; a phone call pauses the camera, resume tracking afterwards.

## Shot classification and insights (replaces the single break tip)
- Every shot gets labels: cut angle (straight-in, slight, medium, thin, very thin; rough bands ~5/20/40/60 degrees, tune later), shot type (stun/follow/draw, short/medium/long), bank/kick (rails used), safety, combo, break.
- Insights show only when the user filters to a category. End-of-session screen stays headline numbers only (remove the "move half a diamond right" tip from that screen).
- Breaks: group by where you broke from (left/center/right of head string, distance from rail in diamonds), what you aimed at (head ball / second ball), and results (balls made, cue ball position, scratches).
  - Different spots with enough breaks each (about 4-5+): comment only on the difference between groups.
  - Same spot every time: no position advice, offer a theory-based tweak (speed, tip position) as a suggestion.
  - Too few breaks: say nothing. Always say how many breaks it is based on.
- Still open: cut band names, whether to track which ball the break aims at.

## Decided: cut names and breaks
- Cut names by ball coverage: Straight 0-7, Three-quarter ~7-22, Half ball ~22-39, Quarter ball ~39-56, Sliver 56+ (degrees on tap).
- Break aim (head ball / second ball) tracked automatically from first contact; shown only in the Breaks filter.
- Filters can be combined (e.g. Quarter ball + draw + long). Insights only with enough matching shots; always show sample size. Optional trend (make rate over recent sessions).

## Build stages (proposed, build only on "make it")
1. Feel test: home, landscape camera, auto/manual calibration, ball detection + tag toggle, one best shot (ghost ball, aim line to pocket center, strength 1-10), pocket presets, diamonds, teal look, strength calibration. Goal: prove table + ball reading on a real table.
2. Position play: landing zone, locked candidate, Safe-Bold slider, scratch/ball-in-hand, diamond ruler toggle, advanced slices.
3. Memory: auto made/missed, shot labels (start saving in stage 1-2), table profiles, save/resume, end-of-session stats.
4. Review: clips, top 10 / misses, combined filters, insights, break grouping (most costly for battery/storage).
5. Extras: bank/kick trainer, training mode, safeties detail, TV mode, drift suggestion.

## Stage 1 UI decision
- Stage 1 shows the full play-screen UI over live video (top pills, bottom-left tip diagram + strength + option arrows, Safe-Bold slider on right edge). Controls for later stages are visible but inert. Open: dim inert controls slightly vs full brightness.
- DECIDED: controls not running yet are drawn in a red hue, same transparency and glass look as the teal ones (replaces the dim-vs-full-brightness question). Temporary: each turns teal when its stage ships. Watch for confusion with red = hard in the landing zone (zone not in stage 1, so no clash yet).

## STATUS: Stage 1 built (user said "make it") and delivered as site/index.html
- Teal glass dark UI, Inter. Red glass = not running yet: Train (home), Safe-Bold slider, diamond ruler, shot style, table profile.
- Working: home, auto/manual calibration, play 9/8-ball plan (ghost ball, aim line, strength 1-10, option arrows), teach balls, strength calibration, pocket presets (planner scale 0.9/1/1.17), ball number tags toggle (off).
- Removed for now: landing zone, target ring, pct/text in HUD.
- Not yet shown anywhere in Stage 1: diamond units (no distances displayed).
- Tested only on synthetic fake camera. Real-table test is the point of Stage 1.
- Fix after first real test: video skewed after rotating (size read while upright). Now syncs size to the live video each frame and waits for sideways before table detection; Back to menu on rotate screen.

## Round 2 fixes (internal only, built into /home/claude/site/index.html but NOT delivered; waiting for "make it")
Tested against the user's real photo (blue cloth, long-side low angle) used as the fake camera.
- Table finder: felt-colour mask (cushion faces excluded) -> hull -> best 4-gon -> straightened edges. Works from any side/angle. Rot (which way table is turned) chosen from side-pocket darkness, not edge length.
- Diamonds: finds white marks on the rails, fits rail offset/height automatically, refines the 4 corners. 18 of 18 on the photo at 800, 1280 and 16:9 crop. Teal diamond marks shown on the verify screen with the count.
- Balls: sphere-size model (balls are circles, not ellipses), thin-strip filter, pocket-blob filter, navy ball on blue felt, colour priors retuned (stripe vs solid). Auto table-size guess from ball size (photo picked 8 ft).
- Cards: verify/manual card is a slim bar at the bottom (or top when table is low), taps pass through except on buttons, so corner dots can be dragged anywhere.
- Open: ids can still swap on odd colour sets (Teach mode fixes); far-rail diamonds are tiny at this angle; lens fixed at 0.86 (auto lens estimate was too noisy); glove/chalk on felt shows up as an unknown ball (tap it, Not a ball).

## Round 3 fixes (live corner-angle report) — built in site/index.html but NOT yet sent
- Cause of phantom/duplicate balls: saved-table path skipped autoSize, wrong ft -> blobs split into extras. Now autoSize + diamond refine run on every table lock (fresh or saved), and liveScan re-runs autoSize if median single-ball area ratio is off (<0.72 or >1.4) three scans running.
- autoSize uses only single-ball blobs (k==1) for scoring.
- Settle logic ignores unlabeled blobs (layoutDiff on labeled only). Unlabeled blobs not drawn except in teach mode.
- Camera-move detection: 128px grayscale reference of area outside the table; diff>9 -> autoCalibrate, if conf>=.75 and corners moved >4px -> re-lock + diamonds + toast; 3 failures -> back to auto-find card.
- Known limit: 4 touching balls in a clump get split as 3.
- Test frame live1 has the app's own overlay baked in, so it is a noisy test; photo169 and move.y4m (A/B shifted frames) used instead.
- Sway tolerance: balls within 0.7" of their previous spot keep it; labeled balls missing <3 scans are held; once settled (stable>=8) full ball scan only every 3rd pass. Whole-picture slide up to 6% of width is followed by sliding the table outline (no re-find, balls keep table coords); only non-slide/big changes re-find the table. Tested with sway.y4m (shifts up to ~2px each 0.3 s): 0 toasts, 0 drift, ids stable.
- Round 3 sent to user after "build it".

## Round 4 (user live test 2) — sent after "build it"? NO: wait for "make it"
- Named/placed/dragged balls are pinned: stay while something non-felt sits there (spotHasBall).
- Table size: once user sets ft (S.ftSet) auto-size only hints, never overrides.
- Shot timing: rVFC frame timestamps (mediaTime) instead of uniform dt; real timestamps passed to analyzeTrack. Old calibrations reset (calVer 2).
- 9-ball/8-ball judging after shot (judgeShot): lowest ball first, rail/pocket after contact, scratch, 9 on foul spotted, win on legal 9. Status "Hit the N first".
- Learn the balls mode (home): circle at 46% height, bg colour from ring, blob in circle, features via 28px shrunk crop, 18 samples per ball (>=250ms apart), saved as walk samples (cl weight 0.2). Look-alike report at end. Portrait allowed.
- Round 4 sent to user after 'Make it'.
- Round 5: half-diamond motion threshold, 9-ball elimination of last unlabeled ball, End session + stats (makes/misses, tracked, ignored nudges), last-session button on home. Sent after 'let's do it'.

## Round 6
- Big bottom-right End session button (#endFab), single tap -> stats.
- Cue vs 9: ball "band" feature (stripe band vs specks) added to featCost/priors; after a shot, unmoved balls keep ids, cue = tracker end point.
- Persistent pinch zoom 1-4x (digital crop = view rect), detector/diamonds get the crop; quad stored in whole-frame coords; saved; badge resets to 1x. Learn mode forces 1x.
- Scratch: when cue ball is missing after a shot -> SCRATCH banner (fades after ~4s) + pulsing ring at best ball-in-hand spot (bestCuePlacement via bestEase vs legal targets).
- Sounds: ding at shot detect, dong at result; More menu Sound toggle.
- Motion threshold = full diamond (L/8) for stable/plan invalidation (testing).
- Calibration version bumped (calVer 2) -> old saved calibrations reset.

## Round 7
- Debug log (DBG): events table/hb/flip/unid/unsettle/relock/shot_start/shot_end/after/judge/plan*/manual/toast/snd/error; Save debug button on stats (share sheet -> download -> textarea); persisted to localStorage 'chalkline.dbg'.
- Sound: WAV clips via Audio elements unlocked on touchend/click, WebAudio back-up, all logged ('snd').
- mergeLabels: global nearest pairing, reach 2.6"; shake skip in checkMoved (jump>1.5px or fd>5, up to 4 passes); setN threshold 4.

## Versioning (agreed with user)
- Major round N: label V1.N, file indexN.html (const BUILD in app.js). Minor revision k of the same round: label V1.N.k, file indexN.k.html (set MINOR in app.js). Only deliver on "make it". User deletes old files. Home-screen icon opens index.html, so the user also uploads a copy named index.html if they want the icon to follow.

## Versioning, revised (user, Oct 9)
- No more "stages": the version number IS the stage. V1 = current (core recognition, planner, stats, debug). V2 = what used to be stage 2, etc.
- Roadmap: V1-V2 alpha builds -> V3 = debugging-finished -> V4 = finished, polished first release -> updates afterwards; alpha -> beta later, using normal release practice.
- Label: V<major>.<round>[.<minor>]  (V1.7, V1.7.1, V2.1). Files carry the full version from the next build on: index1.8.html, index1.7.1.html, index2.1.html (V1.7 shipped as index7.html).

## Versioning, final (user, Oct 9)
- Always ship a single file named index.html. Version is shown only inside the app (top of first screen, V1.7.1 style, and in the debug file). No versioned file names.

## V1.7.2 (Oct 10)
- Duplicate numbers fixed: hold step skips a ball whose number is already on the table; dedupeIds() after hold and after eliminate().
- Positions: median of last 7 readings (f.obs); "moved" still = a diamond; plan redone when a ball shifts >1.5in on 2 scans.
- Player in the way: detectBalls() marks blockers (edge-touching ratio>6, ratio>22, long-thin fill<0.2 ratio>=2.5) -> info.occ grid (+1.3 ball radius) and occFrac; never split into phantom balls. Hidden balls kept (hid) with no countdown; fragments next to blockers dropped (1.6in). Arming needs a visible cue; cue hidden by the cue tip within 2in keeps arming alive.
- checkMoved(): edge-pixel match (ref.eb, gmatch) tells person-in-front from camera move; relock keeps balls (table inches); no automatic beginAuto; "Cannot see the table" status; ref re-snapped after 10 clear steady scans if it contained a person.
- Shot result: afterShot -> S.pend when blocked; pendReady (all balls seen with trusted count / clear view), forced on next kept shot (endShot), timeout 20s -> partial (only certain drops). Count from S.tableN (updated only on clear, steady views; not between shot end and afterShot). cueGone remembered (scratch survives cue put back). firstHit 0 = unknown. Unread drops '?' handled in judge text. holdStatus keeps results on screen.
- Tracking runs inside requestVideoFrameCallback (generation token). Camera restart (track ended / no frames 3 s / back from background) with 8 s timeout; camera settings logged ('cam').
- Tests: scratchpad t172a (dups/median), t172occ (occ.y4m, big.y4m), t172pend, t172shot (shot, shotocc2, scratch), t172cam, rail.py (rail3) + runall.sh regression.
- Known: autoSize can flip 8<->9 ft on some frames (pre-existing); color ID still confuses 4/2 when the real 2 is hidden.

## V1.7.3 (Oct 10, from the user's first real debug log, home 7 ft table)
- Log showed 14 false "camera moved" relocks (people walking by) onto outlines 60-175 px off -> balls jumped -> phantom shots; autoSize flipped 7->9 ft mid-game; ding fired for white things off the table; 2 never learned.
- checkMoved: rail-diamond check first (diamondsFit, small refit) when S.diaLock >= 8; else / then only after ~2 s of a still picture (S.stillN), candidate within 0.12W, area 0.8-1.25, found twice, diamonds confirm (if available). Failed relock -> S.relockWait (4 s, scans paused) not "in place". tableMoved(): clears arming, no shots for 2.5 s. After 20 s lost: card "Find the table again / Keep waiting". Ref never snapped while someone is over the table.
- Table size: chips on the Table found card (guess preselected), accept = ftSet; never changed mid-game.
- Shots: candidate within 22 in, on the cloth, not in a blocker; ding only after >3 in over 4 points. 3+ balls on a non-break = "not counted".
- Vision: navy-on-blue isCloth rule; SET_LOOK priors measured from the user's own set photo (cue..9); assignIds = optimal (Hungarian) with unnamed/absent options. Synthetic test balls/set_on_table: 9/10 right (8 lost to a black glove left on the cloth).
- Home screen lists balls not yet learned.
- Position zone for the NEXT ball (V1.7.3, user: 'where you want the cue ball to finish for the next one'): next legal ball after the planned pot, its best pocket (2nd only if >=80% as good; side pockets need entry <=55deg, corners <=60, path clear). Cells (1.25in) within 3.6 diamonds: green cut<=15deg & 0.6-2.6 diamonds from the ghost ball; amber <=25deg 0.4-3.0; red <=33deg 0.3-3.3; grey striped = angle fine but another ball blocks (hooked). Skips near pockets and balls. Soft layers 22% (grey 32%), dashed ring on the next ball, faint line to its pocket. Path lines lighter (.55).

## V1.8 (Oct 11)
- Every 9-ball/8-ball start finds the table fresh (phone may have moved). Auto-starts when confident (conf>=0.85, size already set, >=12 diamonds) with toast "Table found (7 ft)"; else the Table found card.
- Fixed cushion shadows (STILL): first 8 scans on a found table record dark/bright non-cloth spots in 0.25in cells. Cells dark in >=half the scans within 4.5R of a cushion are the shadow; dark spots joined to them (glove/chalk lying at the rail) out to 10in go too; 1-cell dilation. Balls are protected in IMAGE space (1.6x their image radius; ball well clear of the band always protected, near the band only if ball-shaped). A learned cell showing plain cloth (dark<5%) 6 scans in a row is given back (arm resting during learning). Reset on new table / tableMoved. With mask on, the 'reaches in from the edge' band widens to 3.5R.
- Ghosts on the cushion line ignored (centre within 0.9R of the cushion). Max 10 balls in 9-ball (16 otherwise), keep best-scored. Pocketed numbers not reused until a new rack (S.gone; 9 on a foul goes back). Ball picker: "Taken off by hand".
- Shot validity: first sighting >9in from the armed cue = not the cue; per-hop speed/off-table checks count rec.bad; ding only after 5 good points and >3in; shot rejected if bad >=3 and >=half the points (walk-by).
- Unseen shots: last settled clear layout (S.snap); next clear settled layout with cue moved and another ball moved/dropped, no shot recorded in between -> recorded from before/after (no speed, first hit unknown), stats "not seen, read after". Cue alone moving = ball in hand. Snap cleared on kept shot / tableMoved.
- Self-correction (9-ball): judged first hit != lowest, no scratch -> S.fix. Next shot starts within 4in of where the cue stopped (no ball in hand) -> it was legal: swap the two numbers everywhere, fix the stats row, learn both looks, toast. Cue moved (ball in hand) -> labels stand.
- Planner/zone: zone graded with two-ball lookahead (shotGrade on next ball + shapeOK natural stop/stun/follow/draw lines to the ball after); on 8->9 only the 9 matters; never in a pocket. valueOf position term uses zone quality; extra phase B2 refines speed/spin for the top 6 pots. Drawn: solid white cue line after contact through each rail to the planned stop, small dot ringed by zone colour; grey striped = hooked.
- Tests: t18strip (synthetic cushion strip + glove: 6 balls, occ 0, tableN set), t18unseen (oc/unseen.y4m), t18auto (second start auto-lock + applyFix both cases), regression runall.sh.
- Review fixes (V1.8): mask stores each learned cell's average colour; a pixel there is skipped only while it still looks like that (sum |dRGB| < 60), so a ball stopping on the shadow is seen. Protection = every found ball and every tracked ball (rail-frozen too), in image space. Heal judged over 6-scan windows (far-side cells have 1-2 px). Per-scan buffers reused. After-shot read uses the mask. Cushion-line ghost cut at 0.6R (frozen balls sit at R). First sighting limit 14in once the cue has been out of sight >0.3s. unseenCheck: movement on named balls, drop must show in named and full counts, layout equal to the last shot's start = re-setup (no shot), "Taken off by hand" removes the ball from the snapshot. applyFix runs in endShot after the shot is kept. S.gone resets when more balls show than could still be up. Ding tolerates the odd bad hop.
- Table map look (user, Oct 11): cloth = median RGB of cloth pixels the camera sees, sampled once at acceptTable (S.felt, saved). Charcoal rails (gradient, bevel line, soft drop shadow), cushions = cloth 35% darker, cloth lit slightly in the middle, faint head string + foot spot, pearl diamonds, pockets with dark rim. Painted into a cached canvas (feltCache). Map balls glossy: shadow, edge darkening, highlight, number on a white disc.

## V1.8.1 (Oct 11) and saved for later
- Post-shot card ("You hit strength X, N mph off the tip, estimated spin, aim vs plan") removed from the screen (user didn't like it). The read is still computed and saved (S.meas, S.history, stats mph) and written to the debug log as 'shot_read'.
- FUTURE (user): when shot VIDEO saving is added, bring this back there: each saved shot clip carries "what happened during the shot" (strength, speed, spin, aim vs plan, first ball hit, result).

## V2 — new path (user, Oct 12). Version plan scrapped and restarted.
Why: the hand-written colour detector can't reliably see/name balls (the navy 2 on blue cloth is often never seen whole).
Direction: collect labeled pictures from real play -> train a small detector (YOLO-nano class) -> run it in Safari
(onnxruntime-web, WebGPU in iOS 26; model file ~6 MB next to index.html, so the repo will hold 2 files then).
Training: in Claude's workspace on CPU (slow, free) or Google Colab free GPU. No Mac, no paid service.
Long-term goals KEPT (come back on top of the new detector): shot planner + cue line through rails + position zone with
two-ball lookahead + hooked areas; 9-ball training/runout practice; replay/video with per-shot read (strength, speed, spin,
aim vs plan, first hit, result) — the post-shot card lives there; drills; strength calibration; table map look (player's
cloth colour, charcoal rails); smaller overlays over the cloth; no text on the cloth; balls always clearly visible.

### V2.0 (Oct 12) — Watch & Learn
- New home mode "Watch & Learn" (S.watch on top of play9 machinery). 8-ball removed (S.game forced 9ball; menu game row hidden).
  Play 9-ball kept as "The V1 shot planner", plus Learn the balls / Calibrate.
- Watch mode: no planning, no zones/lines/ghost/spin panel, no Bold/Safe, no rules/fouls/results panel. Draws only ball rings
  with number tags. Status line: "Watching. Rack N · next: the K · M shots". Ding at shot start, dong when the result is in.
- Shot end = all balls stopped (all modes): settleWatch after the cue ball stops: detectBalls + luminance diff on open cloth
  (occluder grid excluded), quiet >= 0.9 s (balls within 0.4in, changed points < max(6, 0.15%)), cap 25 s; liveScan paused.
- Microphone (watch only, menu toggle, default on): AnalyserNode on AU.ctx polled every 20 ms; onset = 1 ms block energy of
  first difference > 10x running floor; 45 ms refractory; own ding/dong ignored. Strike click = within -450..+80 ms of the
  first cue sighting; contact click = first later click with the cue ball (track, extrapolated <=0.5 s if lost) within
  2R+2in of a ball. Mic retry with audioSession 'play-and-record' if refused.
- First ball hit: camera = first track segment passing a ball (moving toward it) with gap < 0.4+2.5*ipp ("sure") or
  < 1.0+6*ipp with a bend (>=8 deg) / slow-down (<0.6) (ipp = inches per pixel at that ball); else mic; else the fit.
- Truth (lowest-ball rule): rack starts target 1 (session start with n<=7 object balls: target 10-n). Shot with >=1 object
  ball down -> target+1 (2+ down -> rack unsure). New rack when clear count >= min+3 and >= 6. Learning: the first ball
  hit (track, or mic with a strike) -> play sample {id: target, play:1} (cap 15 per id) + cue sample. Logged as 'truth'.
- Pictures: before = last clear settled view (refreshed each second, dropped at each shot end), after = when settled.
  Full-res crop of table+rails (<=1280 px), JPEG 0.85, IndexedDB 'chalkline'/'files' key s<t0>/shotNNN-before|after.jpg +
  labels.json (per ball: vision id, table x/y, px/py/pr in the picture, conf, top matches; truth target, via, objAt, drop,
  mic). Last 3 sessions kept.
- Save debug = zip (store) of log.txt + pictures + labels.json, shared as the file only (no title — the title-only share was
  why the user got a 15-byte "Chalkline debug" text). Fallback: download.
- Pop-ups (menu, ball picker, stats) close on a tap outside; Table found card does not.
- Tests: t2watch(.py/_noft) end-to-end + zip, t2mic (detector), t2micmatch (track/mic first hit), roll.y4m settle test.
- V2.0 review fixes: audioSession 'auto' while the mic listens (audioInit no longer forces 'playback' then), back to
  'playback' on micStop; track ended/mute logged. Analyser fftSize 32768. Settling: motion = cloth/not-cloth flips on open
  cloth (shadows ignored), balls blinking in/out ignored, 12 s cap (timeout noted on the shot). Pictures held on the shot
  (frBef at shot start, frAft at settle end), canvas pool (<=6, busy flag). Mic clock: rVFC captureTime when present
  (VF.cap); lag from the strike click (clamped). Save debug = two taps (pack, then "Share debug file (x MB)") because iOS
  needs the share call right after a tap. "Clear and keep playing" restarts the picture session. Walk samples always kept
  when saving (others trimmed to 260). IndexedDB: onabort, reconnect. Truth waits for a non-empty table to start.
- Tests added: t2truth (target across shots/racks), t2shots (home/live/menu screenshots, tap-outside for picker/stats).

## V2.1 (Oct 12, from the first real Watch & Learn session: 35 shots, 70 pictures)
Findings: table only ~130 of 720 camera rows (low, side view; tall wobbly tripod); balls near the far rail lost at 800 px ->
counted as pocketed -> target drift -> false new racks; arm/cue fragments counted as balls in the before list; ~5 of 9
learned looks had the wrong number; ~30 camera-moved corrections, many during screen taps.
- Analysis picture at up to 1280 px (SRC_MAX) instead of 800.
- Truth model rewritten: clean looks only (no occluder at all, nothing hidden) at arming; nArm = median of last 7; a shot's
  drop = nBefore (clean, before the shot) - nArm (clean, before the next shot), confirmed in truthLook (fallback: the shot's
  own drop if no clean look happened). New rack: nArm >= 8 after min <= 3 or a finished rack. Start: nArm>=8 -> 1 else 10-n.
- Learning only if: target known, rack not unsure, count steady before the shot, hit clearly seen (track sure / bend, or mic
  with strike), not unseen, not doubt. V2.0 play samples dropped once on load (v21 flag).
- Frozen cue ball: a ball within 0.3+2*ipp gap of where the cue sat counts as hit when the cue heads off within ~105 deg.
- Hidden ball: no ball near the path -> first sharp bend (>=15 deg or speed x0.5) >=3in from cushions; object at contact +
  2R along (v_in - v_out); 'see' = fraction of that spot in the before picture unlike the cloth. Logged + labels (inferred).
- Mic: weak clicks (5x floor) kept for contact; strike needs a strong one.
- Ball in hand: hand (occluder) at the cue ball at the start, and (mic healthy, no strike click, v0 < 25 in/s) or v0 < 15
  -> no ding, not a shot, counted as ball in hand.
- Wobble: finger down + 2 s after, and motion sensor rotation > 3 deg/s (+0.7 s) -> nothing read, no shot can start;
  afterwards diamondsFit recheck (refit if moved > max(3 px, 0.3% width)), fresh reference picture.
- "Throw out last shot" button (bottom left): shot leaves stats, its learned looks removed, truth restored from the shot's
  snapshot, labels marked thrown (pictures kept).
- Before pictures only with no occluder at all.
- Tests: t21truth (model + throw-out + migration), t21info (frozen, hidden, hand, wobble).
- Review fixes + later changes (V2.1): 1280 analysis REVERTED (tracking frames dropped in tests) -> instead autoFrame(): after
  the table is accepted in Watch & Learn, zoom the working picture onto table+7in rails (+6%/25% room), z<=2.5; each Watch
  session starts unzoomed. Real session geometry -> z ~1.4 (the user had pinched 1.44 by hand).
- Real-picture replay (shot 3 after-frame rebuilt from labels crop + session quadN): far-rail cue ball and 9 were missed
  because (a) pixels inside-table test used the cloth plane, cutting off the upper half of balls near the far cushion ->
  now pixels past a far side (away from the camera, from cam.C) are re-measured at ball-centre height (rail is higher, still
  outside); far pocket holes excluded from those (pk.r+2.5); bbox includes corners at 2R height; (b) learned shadow mask
  skipped white/bright ball pixels -> mask now skips only cloth-hued pixels (|dh|<28, s>0.2) or dark ones on a dark learned
  spot; (c) pocket filter dropped balls near pocket mouths (pk.r+1) -> now only inside 0.75 pk.r, near the mouth only if
  ball-like. Result on that frame: all 8 balls found (was 6).
- detectBalls work buffers reused (DETB). Truth: odd window median rounded; count went up -> shot's own drop; clean-look
  fallback after 20 s; ball-in-hand only with a hand ON the ball and v0<12 (no strike) or <6; weak click upgraded inside
  the refractory; frozen-ball cos>-0.1, sure only cos>0.2; throw-out disabled while a shot is in flight; LEARNED cleared per
  session; touch freeze capped at 10 s and reset on hide; motion permission asked before the camera; recheck keeps the old
  camera-moved reference unless the diamonds confirmed the table; checkMoved px thresholds scale with S.W/800.
- Known: shotocc2 (V1 play mode test) now arms later because of the 2 s freeze after tapping "Looks right" (test timing).

## V2.2 (built Oct 13) — plan as agreed Oct 12
- Home: Watch & Learn (keep) + NEW "Learn the balls" guided drill (replaces walk-around). Remove Play 9-ball and Calibrate
  strength from home (keep code).
- Drill: balls 1..9, 3 MADE shots each. App draws a ghost zone (hand-sized, turns green when a ball is in it) for the object
  ball and for the cue ball; "Step back… Watching"; ding/dong; a miss -> "shoot it again"; then next spot; then next ball.
  Spots: mostly straight, easy, object near enough to a pocket, cue ball a few feet back; vary pocket/middle/far rail/side
  pockets/shade; choose shots so the shooter stands on the far side or ends (shooting toward the camera; never between
  the phone and the balls; use cam.C). If the ball can't be seen on its ghost (the 2), carry on anyway (certain label).
  Learns live (labels certain) + saves pictures. Summary at the end. Later: stripes 10-15 (more shots, rotate the ball).
- Fix the navy 2: real pictures (session 3) show the 2 hue 199-204 (cloth 199), s 0.98-0.99 (cloth 0.86), v 0.36-0.46
  (cloth 0.93); isCloth navy rule needs s > cl.s+0.15 (=1.01) -> misses. Loosen (e.g. s > min(0.97, cl.s+0.1), v < 0.65 cl.v)
  and test offline on real3 pictures (shots 7-17 are the 2).
- Turn off learning in Watch & Learn (count-based truth drifted when the invisible 2 dropped; 9/13 lessons wrong in session
  2); clear play samples again. Later re-enable only when the order rule AND the camera's top-2 agree.
- Ball in hand: picked-up cue logged as "unseen shot" -> fix. Hand-named balls must stay pinned (spotHasBall fails on the 2).
- Lag (user felt it in V2.1 sessions; hb fps avg ~60, so short stalls): add a stall meter (long frames + what ran), cut work
  after touches (diamondsFit/hiFrame on every recheck, still relearn).
- Ghost balls on arms/cue in before pictures when the arm isn't classed as a person -> tighten.
- Data so far: real1 (35 shots), real2 (56), real3 (51, single ball, certain labels) in scratchpad.

### What V2.2 actually does
- Home: Watch & Learn + Learn the balls (drill). Play 9-ball / Calibrate / walk-around learn: code kept, no home buttons
  (tests start them with __chalk.startMode).
- Navy 2 (vision.js): isCloth navy rule `v < 0.66 cl.v && s > min(0.95, cl.s+0.15)`; navy-core pixels marked (DETB.nv); a blob
  that is mostly navy core (and not thin) is rebuilt by navyBall(): core + felt-hued pixels clearly darker than the felt
  (v < 0.85 cl.v) within 1.6 then 1.1 ball radii, recentred 3x, accepted at ratio 0.5-1.5; same pocket/cushion checks.
  Real3 harness (h22.py/chk2.py): the 2 found in 7 of 7 checkable shots (was 2), and shots 13/15 found a real 2 on the far
  rail; hand-shadow ghosts (shots 8, 41) dropped by the compactness check. No new ghosts over all 51 shots.
- Drill: S.drillMode on top of Watch (S.truth off). drillCands(): pockets x angle x distance, cue 26-42" behind, cut <= 5 deg,
  body (behind the cue, off the table) and lean point must stay out of the camera's sight lines to obj/cue/pocket and must
  not be on the camera's side of the table. drillPlan(): 27 spots over 6 table regions (near/far alternated), easiest few
  per region, pocket varies. Rings 3"/4" (accepted 1.5x), green when in. Ring ball forced to the drill number, other to cue.
  Shot start snapshot (drillShotStart) -> drillResult: made = object drop >= 1, or ball never seen on its ring (taken as
  made; Throw out reverts). Learns the ring ball's look every shot (made or not) as {walk,drill} samples (12 per ball; the
  old walk-around looks of that ball are dropped at the first drill sample). Pictures saved with drill labels.
- Watch & Learn: learns nothing (sureHit still logged); v22 migration clears play samples; unseen shots only logged
  (ball in hand looked like one); pinned (hand-named) balls stay until the next shot; before pictures need stable >= 5;
  no diamond search after touches; 9 ft size toast removed (logged); stall meter in hb (late frames, max ms per work kind).
- Review fixes (V2.2): Watch/drill afterShot names the ball at the tracker's end point the cue ball first (a soft straight
  shot left the cue on the object's spot and it took the object's number -> "scratch, missed"); unseen shots in Watch are
  skipped only when nothing but the cue ball changed (real unseen makes still move the target); pins last until the next
  shot AND at most 60 s; navyBall rejects a core inside a big dark patch (ring 1.3-1.8 r must be mostly ordinary felt);
  drill labels only from balls in view, cue must look white; plan rebuilt on every table lock; throw-out gives back looks
  a drill shot replaced; drill before pictures at stable >= 3; LAG.last reset on stop/hidden.
- Tests: t22drill.py (plan, status, rings, make/miss/throw-out/blind/summary, one real shot through the pipeline),
  t22unseen.py, h22plan.py (spots drawn on a real3 picture), h22.py/chk2.py (navy 2). Old tests start removed modes with
  __chalk.startMode. Known flaky: s11 sway ghosts (V2.1 too), s20 scratch race, t2micmatch stale.

## Ball library (Oct 13, after real4/real5)
- /home/claude/library (see its README): 1851 crops from all sessions, every label checked by eye; feat_data.json.
- Leave-one-session-out naming test: built-in looks 78% -> + library looks 98%. Not-a-ball looks catch 81% of hands
  but call 3.6% of balls not-a-ball. Candidate for the app: ship the library looks as built-in samples (needs "build it").
- real4 (drill) findings: unseen-shot check still fires in the drill (ball moved to next ring); player at the table end
  read as 6 balls (k-split blob) -> allN 8, drops 5-7; drill "made" should be "ring ball gone", not dropN.
- real5 (watch) findings: bridge hand fingers read as 3-4 low-number balls in before pictures -> multi-drops, target
  drift. Plan: a ball must be settled for a few seconds to count as dropped; edge-touching medium blobs = person.
- Lag: hb shows 60 fps, scans 30-60 ms, one 3.5 s stall at a camera restart.
- Replay (replay22.py, truth = hand-checked library): drill "ring ball gone" rule right on 30/31 shots (app 29/31; fixes
  the thrown-out shot 22); 3 ball-move "shots" ignored. Watch: "a ball must have sat still >= 3 s (cue ball always
  counts) before it can count as dropped" -> drop count right on 22/24 shots (app 18/24); 6 s is worse (21).
- Small trained recognizer (library/train2.py, mlp24.json): 24x24 crop + 5 colour numbers -> 64 hidden -> 11 classes
  (cue, 1-9, not-a-ball). Leave-one-session-out 96.5% overall, not-a-ball 194/196. Weak spot: the 9 with its stripe
  turned away reads as the cue ball (real2 shots 45-56). int8 weights 148 KB JSON; 0.14 ms per spot in headless
  Chromium (container CPU), so a scan of ~10 spots costs ~1-2 ms. Candidate to ship alongside or instead of colour naming.
- User wants a TV / big-screen view in the final product (he mirrors the phone to a Roku while testing at home; the
  stutter he saw was the mirroring, not the app). Options for later: a light TV page fed by the phone (laptop/smart-TV
  browser; Roku has no real browser), or a native app with AirPlay/Chromecast second-screen. Shares plumbing with the
  projector mode.

## real6 — pool hall, 9 ft, Watch & Learn (Oct 13 evening)
- Cloth lighter cyan (felt rgb 89,210,245; h~188 s~0.62 v~0.95 vs home s 0.87). Different ball set: bright royal-blue 2,
  black 8 (home: navy 2) -> app swapped 2 and 8 constantly; 33 hand corrections. Spectators' heads/hats/arms in frame.
- Table filled the frame edge to edge (near-left pocket at the picture edge); auto-find gave unstable near corners.
- Outline drifted INSIDE the real table (near corners ~35-60 px, far-left ~27 px): 54 "camera moved" relocks (people
  walking in view of the reference area) each followed by a diamond refit; bright lamp glare on the near rail competes
  with the diamonds. Result: cue ball/balls near the near cushion and left end fell outside -> "not catching balls".
  Fix ideas: cap refits to a small distance from the accepted outline; ignore person areas in the moved check;
  tip: phone farther/higher so every pocket has margin.
- Library: +426 hall crops reviewed (148 labels corrected); app was right 278/341 (82%). Recognizer: home sessions stay
  95-99%; hall judged with home-only training 39% (new venue/ball set); with hall pictures from the first 15-22 shots
  in training, later hall shots 75-88%. => a short Learn-the-balls drill per venue/ball set is the way.
- Lag fine (58 fps, scan p90 68 ms).

## Stripes / 15 balls (agreed Oct 13)
- Goal: know every ball's number (10-15 too). Fallback if stripes prove too hard: groups only — cue, 8, solid, stripe.
- What each game really needs: straight pool / one pocket / bank pool = cue + which balls dropped where; 8-ball = cue,
  8, solid/stripe; 9-ball = 1-9 (the 9 is the only stripe); 10-ball = 1-10 with two stripes, the 9 (yellow) and the
  10 (blue) -> stripe-or-solid + colour settles them (blue solid = 2, blue stripe = 10). Drills need numbers only for
  rotation drills (keep those to 9/10 balls); free-order and pattern drills need "a ball dropped" / position only.
- Hard case: a stripe rolled band-up/away looks white (the 9 vs cue confusion already seen). Handle with: numbers held
  while a ball doesn't move, elimination, the cue ball's red dots, a stripes drill that shows each stripe in several turns.
- Order: after 1-9 are solid (likely ~V2.5). Play 9-ball returns (experimental) once Watch & Learn tracks a full rack.
- Next build (V2.3) list: auto camera zoom 0.5-1x (narrowest that fits table + margin, lens model follows zoom); outline
  held to the accepted one (tiny refits only), people ignored in the camera-moved check; ball must sit still 3 s to
  count as dropped (cue always); drill = only cue + called ball, made = ring ball gone, no unseen shots, own-guess vs
  called logged + per-ball score, extra blobs saved as not-a-ball; trained recognizer (library) for naming + hands;
  Watch & Learn learns from hand corrections (certain labels).
