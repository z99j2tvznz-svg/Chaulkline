import re, base64, io
from PIL import Image, ImageDraw
t=open('/home/claude/src/template.html').read()
strip=lambda s: re.sub(r"if \(typeof module[\s\S]*$","",s)
core=strip(open('/home/claude/src/core.js').read()); vis=strip(open('/home/claude/src/vision.js').read()); app=open('/home/claude/src/app.js').read()
body=t.replace('/*CORE*/',core).replace('/*VISION*/',vis).replace('/*APP*/',app)
open('/tmp/claude-0/-home-claude/98017ec1-4128-57de-bccb-96e702253347/scratchpad/all.js','w').write(core+vis+app)
# icon
im=Image.new('RGB',(180,180),(13,19,24)); d=ImageDraw.Draw(im)
d.rounded_rectangle((26,50,154,130),10,fill=(29,107,87),outline=(75,53,39),width=6)
d.ellipse((118,78,140,100),fill=(244,241,232)); d.line((40,112,112,90),fill=(70,184,242),width=5)
b=io.BytesIO(); im.save(b,'PNG'); icon='data:image/png;base64,'+base64.b64encode(b.getvalue()).decode()
head=f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="Chalkline">
<meta name="theme-color" content="#0d1318"><link rel="apple-touch-icon" href="{icon}"><link rel="icon" href="{icon}">
'''
body=body.replace('<title>Chalkline</title>','<title>Chalkline</title>',1)
# split: title+link+style go in head, rest in body
idx=body.index('<div id="home">')
out=head+body[:idx]+'</head><body>\n'+body[idx:]+'\n</body></html>\n'
import os; os.makedirs('/home/claude/site',exist_ok=True)
open('/home/claude/site/index.html','w').write(out)
print(len(out))
